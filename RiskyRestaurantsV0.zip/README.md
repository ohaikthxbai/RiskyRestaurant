# RiskyRestaurant

Authors (A-Z)
---
- Daniel
- Justin
- Livio
- Robert

Heroku
--
https://riskyrestaurant.herokuapp.com/?

Problem
---
Have you ever wondered if the restaurant you are taking the love of your life to is clean or dirty? If they passed government regulations and inspections? Look no further.

Solution
---
With Risky Restaurant, the user has the ability to see which restaurants have passed government regulations and inspections in terms of cleanliness. 

Just simply type the name of the restaurant and choose from the list the one you are looking for!
Cleanliness is determined as follows: 
1)	A scale of 1-3.
  -	1 => not clean.
  - 2 => moderate
  -	3 => extremely clean.
2)	Pass or Fail inspection.

With these two indicators, the user now possesses the ability to choose a clean or dirty restaurant that they would like to indulge in. 

Step By Step
---
blah blah blah

Future Add-ons
---
blah blah blah
